@include('abc')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$(#hide).on('click',  function(){
   $(this).closest('tr').fadeOut('slow', function(){
   	$(this).remove();
   });
});
  
    

</script>
	<div class="container-fluid"  style="padding-left: 270px">

	<center><h3 style="color: red">
		Booked Date
	</h3>
	</center>
	<h1></h1>
<table class="table table-striped table-bordered table-success table-sm	"  style="border:1px solid black; border-collapse: collapse;width:100%">
		<thead class="thead-inverse" style="background-color: #dff0d8">
	  <tr>
        

        <th style="padding: 3px;border-bottom: 1px solid black;width:15%">Client_Id</th>
        <th style="padding: 3px;border-bottom: 1px solid black;width:20%"">Event_name</th>        
		<th style="padding: 3px;border-bottom: 1px solid black;width:20%"">Occupied_Date_From</th>
        <th style="padding: 3px;border-bottom: 1px solid black;width:20%">Occupied_Date_To</th>
		
</tr>
</thead>
		
@foreach($client as $Clients)
	  <tr id="tobehide" data-href= "{{ ('bookingdatafetchbyclick')}}"> 
	      <th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->client_id}}</th>
	     <th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->event_name}}</th>
	     <th style="padding: 3px;border-bottom: 1px solid black;">{{  $Clients->start_confirmed_date }}</th>
		 <th style="padding: 3px;border-bottom: 1px solid black;">{{ $Clients->end_confirmed_date}}</th>
      </tr>
	  
@endforeach	  




	  </table>



 




	</div>


