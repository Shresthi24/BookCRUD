 
      <link href="{{asset('css/dist/css/footer.css')}}" rel="stylesheet">
    



<footer>
    <div class="footer-style" style="position: fixed;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4 col-sm-4 text-left">
                        <!--	<p><a target="_blank" href="http://intelliadmissions.org/faqs"> Click here for Frequently Asked Questions </a></p>  -->
                </div>
                <div class="col-md-4 col-sm-4 text-center">
                
                        <!-- <p>For technical help email us at <a>admissions@intellinects.org</a></p>  -->
                </div>
                <div class="col-md-4 col-sm-4 " style="text-align:-webkit-right;" >
                
                    <img class="img-responsive" src="{{ asset('images/Meavita.png') }}" class="power-style">
                </div>
            </div>
        </div>
    </div>
</footer>


