@extends('layouts.admission_platform.index')
@section('bootstraplink')

  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Jasper">

    <!-- Bootstrap Core CSS -->
    <link href="{{asset('css/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" >
  
     <!-- MetisMenu CSS -->
    <link href="{{asset('css/vendor/metisMenu/metisMenu.min.css')}}" rel="stylesheet">

    <!-- fontawesome -->
    <link href="{{asset('css/vendor/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css">
	
     <!-- jQuery -->
     <script src="{{asset('css/vendor/jquery/jquery.min.js')}}"></script>
	
     <!-- Bootstrap Core JavaScript -->
     <script src="{{asset('css/vendor/bootstrap/js/bootstrap.min.js')}}"></script>


@endsection

@section('p')



@endsection