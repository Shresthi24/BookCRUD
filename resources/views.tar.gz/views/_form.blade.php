    @section('css')
    <link rel="stylesheet" href="{{ asset('css/forms.css') }}">
    @endsection

    <div class="container-fluid">
    <center >
     <div class="jumbotron" style="height: 300px;width:800px;background-color: lavender ">

    <div class="form-group">
        {!! Form::hidden('ifformsubmitted', '1' , [ 'class'=>'form-control']) !!}
            <div class="help-block with-errors"></div>
        </div>

<div class="form-group">
        {!! Form::hidden('Vendor_id', $getvendorid , [ 'class'=>'form-control']) !!}
            <div class="help-block with-errors"></div>
        </div>


     <div class="row">
          

     <div class="col-md-4 col-sm-4 col-xs-12">
    <div class="form-group">
        {!! Form::label('Vendor First Name')  !!}
        <span class="text-danger ">*</span>
        <div>

            {!! Form::text('vendor_1st_name', null, 
                array('required',
                'class'=>'form-control',
                'placeholder'=> 'Your First Name '
                ) )!!}
            <div class="help-block with-errors"></div>
        </div>
          @if ($errors->has('FirstName')) 
                                <p class="help-block" style="color: Red">
                                {{ $errors->first('FirstName') }}
                                </p>
                                 @endif
    </div>
    </div>


     <div class="col-md-4 col-sm-4 col-xs-12">
    <div class="form-group">
        {!! Form::label('Vendor Mid Name') !!}
        <div>
            {!! Form::text('vendor_mid_name', null, 
               array( 
                'class'=>'form-control',
                'placeholder'=> 'Your Mid Name '
                )) !!}
            <div class="help-block with-errors"></div>
        </div>

    </div>
    </div>

     <div class="col-md-4 col-sm-4 col-xs-12">
    <div class="form-group">
        {!! Form::label('Vendor Last Name')  !!}
        <span class="text-danger ">*</span>
        <div >
            {!! Form::text('vendor_last_name', null, 
               array( 'required',
                'class'=>'form-control',
                'placeholder'=> 'Your last Name '
                )) !!}
            <div class="help-block with-errors"></div>
        </div>
          @if ($errors->has('LastName'))
                                 <p class="help-block" style="color: Red">
                                 {{ $errors->first('LastName') }}
                                 </p> 
                                 @endif
    </div>
    </div>
    </div>



    <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
    <div class="form-group">
        {!! Form::label('Business Contact Number')  !!}
        <span class="text-danger ">*</span>
        <div class="input-group">
         <span class="input-group-addon" style="width:10%; font-weight:bold">+91</span>
    {!! Form::text('con_num_1', null,array('required','class'=>'form-control','placeholder'=> 'Business Contact Number')) !!}
            <div class="help-block with-errors"></div>
        </div>
          @if ($errors->has('con_num_1')) <p class="help-block" style="color: Red">{{ $errors->first('con_num_1') }}</p> @endif
    </div>
    </div>


    <div class="col-md-6 col-sm-6 col-xs-12">
    <div class="form-group">
        {!! Form::label(' Another Business Number')  !!}
        <div class="input-group">
        <span class="input-group-addon" style="width:10%; font-weight:bold; ">+91</span>
    {!! Form::text('con_num_2', null,array( 'class'=>'form-control','placeholder'=> 'Business Contact Number'    )) !!}
            <div class="help-block with-errors"></div>
        </div>
    </div>
    </div>
    </div>

    <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
    <div class="form-group" id="mail">
        {!! Form::label('Email') !!}
        <span class="text-danger ">*</span>
        <div >
            {!! Form::email('Email', null, 
                array('required',
                'class'=>'form-control',
                'placeholder'=> 'Your Email id '
                )) !!}
            <div class="help-block with-errors"></div>
        </div>
         @if ($errors->has('Email')) <p class="help-block" style="color: Red">{{ $errors->first('Email') }}</p> @endif
    </div>
    </div>



    </div>  
    </div>
    </center>

    <h4>Company</h4>
   <center >
     <div class="jumbotron" style="height: 180px;width:800px;background-color: lavender ">
   <div class="row">
  <div class="col-md-4 col-sm-4 col-xs-12">

<div class="form-group">
    {!! Form::label('Company Name') !!}
    <span class="text-danger ">*</span> :
    <div >
        {!! Form::text('Company_Name', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Company Name '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Company_Name ')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first('Company_Name ') }}
                            </p>
                             @endif
</div>
</div>

  <div class="col-md-4 col-sm-4 col-xs-12">
   <div class="form-group" >
  <label >Service_Type<span class="text-danger">*</span>
  </label>
 {{ Form::select('Service_Type', ['venue','caterer','flowers','decoration','sounds'],null,['class' => 'form-control' ]) }}
 <div class="help-block with-errors"></div>
   </div>
   </div>


<div class="col-md-4 col-sm-4 col-xs-12">
<div class="form-group">
    {!! Form::label('Web-Url')  !!}
    <span class="text-danger ">*</span>
    <div>
        {!! Form::url('web_url', null, 
           array( 'required',
            'class'=>'form-control',
            'placeholder'=> 'Your Web Url '
            ))!!}
        <div class="help-block with-errors"></div>
    </div>
     @if ($errors->has('web_url')) <p class="help-block" style="color: Red">{{ $errors->first('Email') }}</p> @endif

</div>
</div>
</div>
<h4></h4>
<div class="row" style="float:left;">
<div class="form-group">
    {!! Form::label('Is GST applicable:  ')  !!} 
    <span class="text-danger ">*</span>&nbsp;
<span style="color:blue">Yes</span>&nbsp;{{ Form::radio('GST', 'yes') }} &nbsp;&nbsp;
<span style="color:blue">No</span>&nbsp;{{ Form::radio('GST', 'no') }}
</div>
</div>
</div>
</center>
 <h1></h1>
 <h4>Address</h4>

 <center >
     <div class="jumbotron" style="height: 300px;width:800px;background-color: lavender ">

   <div class="row">
   <div class="col-md-6 col-sm-3 col-xs-12">

<div class="form-group">
    {!! Form::label('Country') !!}
     <span class="text-danger">*</span>
    <div >
        {!! Form::text('Country', null, 
           array( 'required',
            'class'=>'form-control',
            'placeholder'=> 'Country '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Country')) <p class="help-block" style="color: Red">{{ $errors->first('Country') }}</p> @endif
</div>
</div>

 <div class="col-md-6 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('Pincode') !!}
     <span class="text-danger">*</span>
    <div >
        {!! Form::text('Pincode', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'Pincode '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Pincode')) <p class="help-block" style="color: Red">{{ $errors->first('Pincode') }}</p> @endif
</div>
</div>
</div>

<div class="row">
<div class="col-md-4 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('State')!!}
     <span class="text-danger ">*</span>
    <div >
        {!! Form::text('State', null,
           array( 'required',
            'class'=>'form-control',
            'placeholder'=> 'State'
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('State')) <p class="help-block" style="color: Red">{{ $errors->first('State') }}</p> @endif
</div>
</div>

 <div class="col-md-4 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('District') !!}
     <span class="text-danger ">*</span>
    <div >
        {!! Form::text('District', null, 
           array( 'required',
            'class'=>'form-control',
            'placeholder'=> 'District '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('District')) <p class="help-block" style="color: Red">{{ $errors->first('District') }}</p> @endif
</div>
</div>

 <div class="col-md-4 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('Area')!!}
     <span class="text-danger ">*</span>
    <div >
       {!! Form::text('Area', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Area '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Area')) <p class="help-block" style="color: Red">{{ $errors->first('Area') }}</p> @endif
</div>
</div>
</div>


<div class="row">

 <div class="col-md-4 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('City') !!}
     <span class="text-danger ">*</span>
    <div >
        {!! Form::text('City', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'City '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('City')) <p class="help-block" style="color: Red">{{ $errors->first('City') }}</p> @endif
</div>
</div>

 <div class="col-md-4 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('Locality') !!}
    <span class="text-danger ">*</span>
     
    <div >
        {!! Form::text('Locality', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Locality '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
     @if ($errors->has('Locality')) <p class="help-block" style="color: Red">{{ $errors->first('Locality') }}</p> @endif
</div>
</div>

<div class="col-md-4 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('Flat Number')!!}
    <div >
        {!! Form::text('flat_no', null, 
            array('class'=>'form-control',
            'placeholder'=> 'Flat Number '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('flat_no'))
                             <p class="help-block" style="color: Red">
                             {{ $errors->first('flat_no') }}
                             </p> 
                             @endif
</div>
</div>
</div>
</div>
</center>


     <h1></h1>
     <center>
     <div class="row" style="margin-bottom: 15px;padding-left: 200px">
                    
    <div class="col-xs-12 text-center">
        <div class="form-group">
        {!! Form::submit('Submit', 
          array('class'=>'btn btn-primary')) !!}
    </div>
    </div>
    </div>
    </center>
    </div>

    {!! Form::close() !!}
