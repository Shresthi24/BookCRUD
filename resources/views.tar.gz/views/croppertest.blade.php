
<html>
    <head>
        <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
        <title>Upload and edit images in Laravel using Croppic jQuery plugin</title>
         <link href="{{asset('css/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" >
        <link href="{{asset('css/croppic/main.css')}}" rel="stylesheet" type="text/css" >
        <link href="{{asset('css/croppic/croppic.css')}}" rel="stylesheet" type="text/css" >


        <link href='http://fonts.googleapis.com/css?family=Lato:300,400,900' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Mrs+Sheppards&subset=latin,latin-ext' rel='stylesheet' type='text/css'>

    </head>
    <body>

        <div class="container">
            <div class="row margin-bottom-40">
                <div class="col-md-12">
                  
                    <h1>croptest</h1>
                </div>
            </div>

            <div class="row margin-bottom-40">
                <div class=" col-md-3">
                  
                    <div id="cropContainerEyecandy">


                    </div>
                </div>
            </div>

      
       <script src=" https://code.jquery.com/jquery-2.1.3.min.js"></script>
        <script src="{{asset('js/croppic/croppic.js')}}"></script> ;
        <script>
var eyeCandy = $('#cropContainerEyecandy');
var croppedOptions = {
    loaderHtml: '<div class="loader bubblingG"><span id="bubblingG_1"></span><span id="bubblingG_2"></span><span id="bubblingG_3"></span></div> ',  
    uploadUrl: '{{route('upload')}}'
    cropUrl: '{{route('crop')}}'
    modal:true,
  
    
};
var cropperBox = new Croppic('cropContainerEyecandy', croppedOptions);
        </script>
        </div>

    </body>
</html>