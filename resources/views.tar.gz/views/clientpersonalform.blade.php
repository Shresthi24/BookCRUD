
    <link href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css" rel="Stylesheet"
        type="text/css" />
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>


<div class="form-group">
    {!! Form::label('Client id') !!}
    <div >
        {!! Form::number('client_id', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Client id '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('client_id ')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first('client_id ') }}
                            </p>
                             @endif
</div>

<div class="form-group">
    {!! Form::label('Client First Name') !!}
    <div >
        {!! Form::datetime('client_1st_name', null, 
            array('required',
            'class'=>'form-control',
            'id'=>'startdate',
            'placeholder'=> 'Client First Name'
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
     @if ($errors->has('client_1st_name')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first('client_1st_name') }}
                            </p>
                             @endif

</div>

<div class="form-group">
    {!! Form::label('client mid name')!!}
    <div >
        {!! Form::text('client_2nd_name', null, 
            array(
            'class'=>'form-control',
            'id'=>'enddate',
            'placeholder'=> 'client Mid Name '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
   </div>

<div class="form-group">
    {!! Form::label('client last name') !!}
    <div >
        {!! Form::text('client_last_name', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'client Last Name'
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
     @if ($errors->has('client_last_name')) <p class="help-block" style="color: Red">{{ $errors->first('client_last_name') }}</p> @endif
</div>
<div class="col-xs-12">
   <div class="form-group">
    {!! Form::submit('Submit', 
      array('class'=>'btn btn-primary')) !!}
</div>
</div>

{!! Form::close() !!}