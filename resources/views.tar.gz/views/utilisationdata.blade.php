@include('abc')
@section('css')
<link rel="stylesheet" href="{{ asset('tour.css') }}">
@endsection



<div class="container-fluid" style="z-index: 800;padding-left:280px">

<div class="right" style="z-index: 800;left-padding:300px">
        <div class="row">
            
                <div class="col-md-4 col-sm-6 col-xs-12">
                   <a href="#" title="Active appointments">
    <div class="info-box" style="display: block;min-height: 90px;background: #fff;width: 100%;box-shadow: 0 1px 1px rgba(0,0,0,.1);
border-radius: 2px;margin-bottom: 15px;">

    <span class="info-box-icon bg-green " style="border-top-left-radius: 2px;border-top-right-radius: 0;background-color: #00a65a !important;border-bottom-right-radius: 0;border-bottom-left-radius: 2px;display: block;float: left;height: 90px;width: 90px;
text-align: center;font-size: 45px;line-height: 90px;background: rgba(0,0,0,.2);text-align: centre;">

<i class="fa fa-check" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;color: #fff !important;text-rendering: auto;align:center"></i></span>

    <div class="info-box-content">
      <span class="info-box-text" style="display: block;font-size: 24px;white-space: nowrap;overflow: hidden;text-overflow:ellipsis;">Total Number of days Available</span>
      <span class="info-box-number"><h2>{{ $client}}</h2></span>
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
</a>
                </div>
            
       
   

                <div class="col-md-4 col-sm-6 col-xs-12">

                   <a href="#" title="Appointment requests">

    <div class="info-box" style="display: block;min-height: 90px;background: #fff;width: 100%;box-shadow: 0 1px 1px rgba(0,0,0,.1);
border-radius: 2px;margin-bottom: 15px;">

    <span class="info-box-icon bg-yellow" style="border-top-left-radius: 2px;border-top-right-radius: 0;background-color: #00a65a !important;border-bottom-right-radius: 0;border-bottom-left-radius: 2px;display: block;float: left;height: 90px;width: 90px;
text-align: center;font-size: 45px;line-height: 90px;background: rgba(0,0,0,.2);text-align: center;">

<i class="fa fa-hourglass" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;color: #fff !important;text-rendering: auto;align:center"></i></span>
    <div class="info-box-content">
      <span class="info-box-text" style="display: block;font-size: 24px;white-space: nowrap;overflow: hidden;text-overflow:ellipsis;">Days Booked</span>
      <span class="info-box-number"><h2>{{ $client1}}</h2></span>
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
</a>
                </div>
            
       
   
                <div class="col-md-4 col-sm-6 col-xs-12">
                   <a href="#" title="Total Appointment">
    <div class="info-box"  style="display: block;min-height: 90px;background: #fff;width: 100%;box-shadow: 0 1px 1px rgba(0,0,0,.1);
border-radius: 2px;margin-bottom: 15px;">

    <span class="info-box-icon bg-blue" style="border-top-left-radius: 2px;border-top-right-radius: 0;background-color: #00a65a !important;border-bottom-right-radius: 0;border-bottom-left-radius: 2px;display: block;float: left;height: 90px;width: 90px;
text-align: center;font-size: 45px;line-height: 90px;background: rgba(0,0,0,.2);text-align: center;">

<i class="fa fa-table" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;color: #fff !important;text-rendering: auto;align:center"></i></span>
    <div class="info-box-content">

      <span class="info-box-text" style="display: block;font-size: 24px;white-space: nowrap;overflow: hidden;text-overflow:ellipsis;">Free Days</span>
      <span class="info-box-number"><h2>{{ $client2}}</h2></span>
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
</a>
                </div>
            
        </div>
      
   

</div>
</div>




