@include('abc')
<script src='vendor/assets/lib/jquery.min.js'></script>

	
	<div class="container-fluid" style="padding-left: 270px">
<table class="table table-striped table-bordered table-success table-sm	" style="border:1px solid black; border-collapse: collapse;width:100%">
		<thead class="thead-inverse" style="background-color: #dff0d8">
	  <tr>
      <th style="padding: 3px;border-bottom: 1px solid black;">Client_id</th>
			<th style="padding: 3px;border-bottom: 1px solid black;">First Name</th>
        <th style="padding: 3px;border-bottom: 1px solid black;">Mid name</th>
		<th style="padding: 3px;border-bottom: 1px solid black;">Last name</th>
        <th style="padding: 3px;border-bottom: 1px solid black;">Date of Payment </th>
		 <th style="padding: 3px;border-bottom: 1px solid black;">Amount</th>
</tr>
</thead>

	

 @foreach($client as $Clients)
	    
	  <tr class='clickable-row' data-href= "{{ ('bookingdatafetchbyclick')}}"> 
	   <th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->Client_id}}</th>
	     <th style="padding: 3px;border-bottom: 1px solid black;">{{ $Clients->Client_first_name}}</th>
	     <th style="padding: 3px;border-bottom: 1px solid black;">{{ $Clients->Client_mid_name}}</th>
	     <th style="padding: 3px;border-bottom: 1px solid black;">{{  $Clients->Client_last_name}}</th>
		 <th style="padding: 3px;border-bottom: 1px solid black;">{{ $Clients-> date_com_pay }}</th>
		 <th style="padding: 3px;border-bottom: 1px solid black;">{{ $Clients->Complete_payment }}</th>
		  
	  </tr>
@endforeach	  
	  </table>
	  <h1></h1>
	  <div class="row">
	  <div class="col-md-6">
	   <center><button type="button" class="btn btn-warning" style="width:70px;height: 40px;
	   background-color:#A9A9F5;border-radius:10px;border-color:#5858FA;float: right;"><a href="#" ><p style="color:black;font-size:20px">Sum</p>
	   </a>
	   </button>
	   </center>
	  	
	 
	  </div>
	  <div class="col-md-6">
	  	<h1 style="font-size: 30px;font-family:Georgia ;font-color:blue"> {{$client1}} </h1> 
	  </div>
	 </div>
</div>
	  

	
 


