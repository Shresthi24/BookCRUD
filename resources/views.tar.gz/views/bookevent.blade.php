@include('abc')
 <div class="container-fluid" style="padding-left: 170px; z-index: 800">

	<table>
		<tr>
			<td> Client_id </td>
			<td> Client First Name </td>
			<td> Client Mid Name </td>
			<td> Client Last Name </td>
		</tr>

			
				foreach ($client as $value)
		{
		<tr>
			<td> {{$value-> Client_id}} </td>
			<td> {{$value->Client_first_name}} </td>
			<td> {{$value->Client_mid_name}} </td>
			<td> {{$value-> Client_last_name}} </td>
		</tr>
			}

	

	</table>



 </div> 