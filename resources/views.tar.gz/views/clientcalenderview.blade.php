
@include('layouts.app')
<meta charset='utf-8' />
<link href='vendor/assets/fullcalendar.min.css' rel='stylesheet' />
<link href='vendor/assets/fullcalendar.print.min.css' rel='stylesheet' media='print' />
<script src='vendor/assets/lib/moment.min.js'></script>
<script src='vendor/assets/lib/jquery.min.js'></script>
<script src='vendor/assets/fullcalendar.min.js'></script>
<script>

  $(document).ready(function() {
//var token=$('meta[name="csrf-token"]').attr('content');

    $('#calendar').fullCalendar({
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay'
      },
      defaultDate: moment(),
      navLinks: true, // can click day/week names to navigate views
      editable: false,
      eventLimit: true, // allow "more" link when too many events
        allDayDefault: false,
            allDaySlot: false,
            slotEventOverlap: false,
       
});
  });

</script>
<style>

  body {
    
  }

  #calendar {
    
  }

</style>



  
    <div class="container" style="margin: 40px 160px;z-index: 800
    padding: 0;
    font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
    font-size: 14px;">

     <div id='calendar' style="max-width: 900px;
    margin: 0 auto;"> 
    </div>
    
    </div>
   

  
