@section('css')
<link rel="stylesheet" href="{{ asset('css/forms.css') }}">
@endsection

<div class="form-group">
    {!! Form::hidden('Vendor_id', $lastinsertid , [ 'class'=>'form-control']) !!}
        <div class="help-block with-errors"></div>
    </div>


<div class="form-group">
    {!! Form::label('Flat Number')!!}
    <div >
        {!! Form::text('flat_no', null, 
            array('class'=>'form-control',
            'placeholder'=> 'Flat Number '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('flat_no'))
                             <p class="help-block" style="color: Red">
                             {{ $errors->first('flat_no') }}
                             </p> 
                             @endif
</div>

<div class="form-group">
    {!! Form::label('Locality') !!}
    <div >
        {!! Form::text('Locality', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Locality '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
     @if ($errors->has('Locality')) <p class="help-block" style="color: Red">{{ $errors->first('Locality') }}</p> @endif
</div>



<div class="form-group">
    {!! Form::label('Taluka') !!}
    <div >
        {!! Form::text('Taluka', null, 
            array('class'=>'form-control',
            'placeholder'=> 'Taluka '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
     @if ($errors->has('Taluka')) <p class="help-block" style="color: Red">{{ $errors->first('Taluka') }}</p> @endif
</div>

<div class="form-group">
    {!! Form::label('District') !!}
    <div >
        {!! Form::text('District', null, 
           array( 'required',
            'class'=>'form-control',
            'placeholder'=> 'District '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('District')) <p class="help-block" style="color: Red">{{ $errors->first('District') }}</p> @endif
</div>

<div class="form-group">
    {!! Form::label('Area')!!}
    <div >
       {!! Form::text('Area', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Area '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Area')) <p class="help-block" style="color: Red">{{ $errors->first('Area') }}</p> @endif
</div>

<div class="form-group">
    {!! Form::label('City') !!}
    <div >
        {!! Form::text('City', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'City '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('City')) <p class="help-block" style="color: Red">{{ $errors->first('City') }}</p> @endif
</div>

<div class="form-group">
    {!! Form::label('State')!!}
    <div >
        {!! Form::text('State', null,
           array( 'required',
            'class'=>'form-control',
            'placeholder'=> 'State'
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('State')) <p class="help-block" style="color: Red">{{ $errors->first('State') }}</p> @endif
</div>

<div class="form-group">
    {!! Form::label('Country') !!}
    <div >
        {!! Form::text('Country', null, 
           array( 'required',
            'class'=>'form-control',
            'placeholder'=> 'Country '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Country')) <p class="help-block" style="color: Red">{{ $errors->first('Country') }}</p> @endif
</div>

<div class="form-group">
    {!! Form::label('Pincode') !!}
    <div >
        {!! Form::text('Pincode', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'Pincode '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Pincode')) <p class="help-block" style="color: Red">{{ $errors->first('Pincode') }}</p> @endif
</div>
