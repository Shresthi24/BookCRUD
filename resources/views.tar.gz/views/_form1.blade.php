@section('css')
<link rel="stylesheet" href="{{ asset('css/forms.css') }}">
@endsection

<div class="form-group">
    {!! Form::hidden('Vendor_id', $lastinsertid1 , [ 'class'=>'form-control']) !!}
        <div class="help-block with-errors"></div>
    </div> 

 <div class="form-group">
    {!! Form::hidden('Service_id', $lastinsertid2, [ 'class'=>'form-control']) !!}
        <div class="help-block with-errors"></div> 




 <h4>Particulars for Venue</h4>

 <center >
     <div class="jumbotron" style="height: 300px;width:800px;background-color: lavender ">

     <div class="row">
     <div class="col-md-6 col-sm-3 col-xs-12">
     <div class="form-group">
    {!! Form::label('Venue Name') !!}
    <span class="text-danger ">*</span>
    <div >
        {!! Form::text('  Venue_name', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'Venue Name'       
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Venue_name')) <p class="help-block" style="color: Red">{{ $errors->first('Venue_name') }}</p> @endif
  </div>
    </div>
     </div>

   <div class="row">
 
  <div class="col-md-6 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('Maximum Footfall ') !!}
    <span class="text-danger ">*</span>
    <div >
        {!! Form::number('max_footfall_venue', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'max_footfall_venue'       
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('max_footfall_venue')) <p class="help-block" style="color: Red">{{ $errors->first('max_footfall_venue') }}</p> @endif
</div>
</div>
      
       <div class="col-md-6 col-sm-3 col-xs-12"> 
       <div class="form-group">
    {!! Form::label('Minimum Footfall ') !!}
    <span class="text-danger ">*</span>
    <div >
        {!! Form::number('min_footfall_venue', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'min_footfall_venue'      
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('min_footfall_venue')) <p class="help-block" style="color: Red">{{ $errors->first('min_footfall_venue') }}</p> @endif
</div>
</div>
</div>

<div class="row">
 <div class="col-md-6 col-sm-3 col-xs-12">
         <div class="form-group">
    {!! Form::label('Fixed Price ') !!}
    <span class="text-danger ">*</span>
    <div >
        {!! Form::number('Normal_rent', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'Price'       
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Normal_rent')) <p class="help-block" style="color: Red">{{ $errors->first('Normal_rent') }}</p> @endif
</div>
</div>

 <div class="col-md-6 col-sm-3 col-xs-12">
   <div class="form-group">
    {!! Form::label('Weekend Price') !!}
    <span class="text-danger ">*</span>
    <div >
        {!! Form::number('Weekend_rent', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'Weekend_rent '       
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
@if ($errors->has('Weekend_rent')) <p class="help-block" style="color: Red">{{ $errors->first('Weekend_rent') }}</p> @endif
</div>
     </div>
      </div>
      </div>
</center>
      <h1></h1>
 <h4>Particulars for Service</h4>
 <center >
     <div class="jumbotron" style="height: 140px;width:800px;background-color: lavender ">

   <div class="row">
    <div class="col-md-4 col-sm-4 col-xs-12">
      <div class="form-group">
    {!! Form::label('service Name') !!}
    <span class="text-danger ">*</span>
    <div >
        {!! Form::text('service_name', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'service Name'       
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('service_name')) <p class="help-block" style="color: Red">{{ $errors->first('service_name') }}</p> @endif
</div>
</div>

 <div class="col-md-4 col-sm-4 col-xs-12">
   <div class="form-group">
    {!! Form::label('Fixed Price ') !!}
    <span class="text-danger ">*</span>
    <div >
        {!! Form::number('Normal_rent_service', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'Price'       
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Normal_rent_service')) <p class="help-block" style="color: Red">{{ $errors->first('Normal_rent_service') }}</p> @endif
</div>
</div>

 <div class="col-md-4 col-sm-4 col-xs-12">
   <div class="form-group">
    {!! Form::label('Weekend Price') !!}
    <span class="text-danger ">*</span>
    <div >
        {!! Form::number('Weekend_rent_service', null, 
        array('required',
            'class'=>'form-control',
            'placeholder'=> 'Weekend_rent '       
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
@if ($errors->has('Weekend_rent_service')) <p class="help-block" style="color: Red">{{ $errors->first('Weekend_rent_service')}}</p> @endif
</div>
</div>

</div>
</div>
</center>
    
<h1></h1>

<center>
<div class="col-xs-12">
   <div class="form-group">
    {!! Form::submit('Submit', 
      array('class'=>'btn btn-primary')) !!}
</div>
</div>
</center>

{!! Form::close() !!}