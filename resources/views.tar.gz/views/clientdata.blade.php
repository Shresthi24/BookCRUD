@include('abc')


	<div class="container-fluid" style="padding-left: 270px">
<table class="table table-striped table-bordered table-success table-sm	" style="border:1px solid black; border-collapse: collapse;width:100%">
		<thead class="thead-inverse" style="background-color: #dff0d8">
	  <tr>
        

        <th style="padding: 3px;border-bottom: 1px solid black;width:15%">Vendor Id</th>
        <th style="padding: 3px;border-bottom: 1px solid black;">FirstName</th>
        
		<th style="padding: 3px;border-bottom: 1px solid black;">lastname</th>
       
		
</tr>
</thead>



@foreach($client as $Clients)
	  <tr>
	  
 <th style="padding: 15px;border-bottom: 1px solid black;">
 <a href="{{('clientpersonaldata/'. $Clients->Vendor_id)}}"> 
 {{$Clients->Vendor_id}}
 </a>
 </th>
<th style="padding: 15px;border-bottom: 1px solid black;">{{$Clients->Vendor_1st_name}} </th>
<th style="padding: 15px;border-bottom: 1px solid black;">{{$Clients->Vendor_last_name}}</th>
		
      </tr>
     @endforeach

 </table>
 





</div>