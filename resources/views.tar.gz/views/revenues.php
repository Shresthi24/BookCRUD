@extends('layouts.app')

@section('css')
<link rel="stylesheet" href="{{ asset('tour.css') }}">
@endsection


@section('content')
<div class="container-fluid" style="background-color: #ecf0f5;z-index: 800;">


        <div class="row" >
         <div class="col-md-4 col-sm-3">
</div>
            
                <div class="col-md-4 col-sm-6 col-xs-12">
  
    <div class="info-box-content" style="top-margin:30px">
      <span class="info-box-text" style="display: block;font-size: 24px;white-space: nowrap;overflow: hidden;text-overflow:ellipsis;text-align:center;top-margin:25px">Possible revenue this month</span>
     
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->

                </div>
            </div>


        <div class="row" >
            <div class="col-md-4 col-sm-3">
</div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                   <a href="#" title="Earnings this month">
    <div class="info-box" style="display: block;min-height: 90px;background: #fff;width: 100%;box-shadow: 0 1px 1px rgba(0,0,0,.1);
border-radius: 2px;margin-bottom: 15px;">


<span class="info-box-icon bg-green " style="border-top-left-radius: 2px;border-top-right-radius: 0;background-color: #00a65a !important;border-bottom-right-radius: 0;border-bottom-left-radius: 2px;display: block;float: left;height: 90px;width: 90px;
text-align: center;font-size: 45px;line-height: 90px;background: rgba(0,0,0,.2);text-align: centre;top-padding:10px">

<i class="fa fa-money" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;color: #fff !important;text-rendering: auto;align:center;top-margin:10px"></i></span>

    <div class="info-box-content">
      <span class="info-box-text" style="display: block;font-size: 24px;white-space: nowrap;overflow: hidden;text-overflow:ellipsis; text-align:center">Earnings this month</span>
     
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
</a>
                </div>
            </div>


        <div class="row" >
            <div class="col-md-4 col-sm-3">
</div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                   <a href="#" title="Total Earning through Meavita.">
    <div class="info-box" style="display: block;min-height: 90px;background: #fff;width: 100%;box-shadow: 0 1px 1px rgba(0,0,0,.1);
border-radius: 2px;margin-bottom: 15px;">


<span class="info-box-icon bg-green " style="border-top-left-radius: 2px;border-top-right-radius: 0;background-color: #00a65a !important;border-bottom-right-radius: 0;border-bottom-left-radius: 2px;display: block;float: left;height: 90px;width: 90px;
text-align: center;font-size: 45px;line-height: 90px;background: rgba(0,0,0,.2);text-align: centre;top-padding:20px">

<i class="fa fa-calender" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;color: #fff !important;text-rendering: auto;align:center;top-margin:10px"></i></span>

    <div class="info-box-content">
      <span class="info-box-text" style="display: block;font-size: 24px;white-space: nowrap;overflow: hidden;text-overflow:ellipsis;text-align:center">Total Earning through Meavita.</span>
     
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
</a>
                </div>
            </div>



@endsection



