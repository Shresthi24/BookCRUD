@section('css')
<link rel="stylesheet" href="{{ asset('css/forms.css') }}">
@endsection

 <div class="form-group">
    {!! Form::hidden('Vendor_id', $lastinsertid , [ 'class'=>'form-control']) !!}
        <div class="help-block with-errors"></div>
    </div> 


 <center >
     <div class="jumbotron" style="height: 300px;width:800px;background-color: lavender ">
   <div class="row">
  <div class="col-md-6 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('Account holder name')  !!}
    <div>
        {!! Form::text('Account_holder_name', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Account holder name '
            ) )!!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Account_holder_name')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first('Account_holder_name') }}
                            </p>
                             @endif

</div>
</div>

<div class="col-md-6 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('Account Number') !!}
    <div>
        {!! Form::number('Account_Number', null, 
           array( 'required',   
            'class'=>'form-control',
            'placeholder'=> 'Account Number '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
    @if ($errors->has('Account_Number'))
                             <p class="help-block" style="color: Red">
                             {{ $errors->first('Account_Number') }}
                             </p> 
                             @endif

</div>
</div>
</div>

   <div class="row">
  <div class="col-md-4 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('Bank Name')  !!}
    <div >
        {!! Form::text('Bank_Name', null, 
           array( 'required',
            'class'=>'form-control',
            'placeholder'=> 'Bank Name '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Bank_Name'))
                             <p class="help-block" style="color: Red">
                             {{ $errors->first('Bank_Name') }}
                             </p> 
                             @endif
</div>
</div>

 <div class="col-md-4 col-sm-3 col-xs-12">
<div class="form-group" id="mail">
    {!! Form::label('Branch') !!}
    <div >
        {!! Form::text('Branch', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Branch '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
     @if ($errors->has('Branch')) <p class="help-block" style="color: Red">{{ $errors->first('Branch') }}</p> @endif
</div>
</div>


 <div class="col-md-4 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('Branch code')  !!}
    <div>
        {!! Form::number('Branch_code', null, 
           array( 'required',
            'class'=>'form-control',
            'placeholder'=> 'Branch code'
            ))!!}
        <div class="help-block with-errors"></div>
    </div>
     @if ($errors->has('Branch_code')) <p class="help-block" style="color: Red">{{ $errors->first('Branch_code') }}</p> @endif
</div>
</div>
</div>

<div class="row">
  <div class="col-md-6 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('IFSC')  !!}
    <div >
        {!! Form::text('IFSC', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'IFSC '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('IFSC')) <p class="help-block" style="color: Red">{{ $errors->first('IFSC') }}</p> @endif
</div>
</div>

 <div class="col-md-6 col-sm-3 col-xs-12">
<div class="form-group">
    {!! Form::label('GST')  !!}
    <div >
        {!! Form::text('GST', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'GST '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('GST')) <p class="help-block" style="color: Red">{{ $errors->first('GST') }}</p> @endif
</div>
</div>
</div>
</div>
</center>
<h1></h1>
<center>
<div class="col-xs-12">
    <div class="form-group">
    {!! Form::submit('Submit', 
      array('class'=>'btn btn-primary')) !!}
</div>
</div>
</center>
{!! Form::close() !!}