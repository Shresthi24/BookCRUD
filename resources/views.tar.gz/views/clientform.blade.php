    <link href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css" rel="Stylesheet"
        type="text/css" />
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script>
        $(document).ready(function () {
          var dt = new Date();
            $("#startdate").datepicker({
                minDate: 0
                 //minDateTime: dt,
                 //format:'m/d/Y H:i',
                 format:'YYYY/MM/DD'
            });
        });



    </script>
    <input type="hidden" name="_csrf_token"
    value="{{ csrf_token() }}">


    <div class="form-group">
    {!! Form::hidden('Vendor_id', $id , [ 'class'=>'form-control']) !!}
        <div class="help-block with-errors"></div>
    </div>

  
 <center >
     <div class="jumbotron" style="height: 300px;width:800px;background-color: lavender ">
     <div class="row">
      <div class="col-md-6 col-sm-6 col-xs-12">
<div class="form-group">
    {!! Form::label('Client id') !!}
    <div >
        {!! Form::number('client_id', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Client id '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('client_id ')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first('client_id ') }}
                            </p>
                             @endif
</div>
</div>

 <div class="col-md-6 col-sm-6 col-xs-12">
<div class="form-group">
    {!! Form::label('Event Name ') !!}
    <div >
        {!! Form::text('event_name', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'event name'
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('event_name')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first('event_name') }}
                            </p>
                             @endif
</div>
</div>
</div>

<div class="row">
 <div class="col-md-4 col-sm-4 col-xs-12">
<div class="form-group">
    {!! Form::label('Client first name  ') !!}
    <div >
        {!! Form::text('Client_first_name', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> 'Client first name  '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Client_first_name')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first('Client_first_name') }}
                            </p>
                             @endif
</div>
</div>

 <div class="col-md-4 col-sm-4 col-xs-12">
<div class="form-group">
    {!! Form::label('Client mid name') !!}
    <div >
        {!! Form::text('Client_mid_name', null, 
            array('class'=>'form-control',
            'placeholder'=> 'Client mid name'
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Client_mid_name')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first('Client_mid_name') }}
                            </p>
                             @endif
</div>
</div>

 <div class="col-md-4 col-sm-4 col-xs-12">
<div class="form-group">
    {!! Form::label(' Client last name') !!}
    <div >
        {!! Form::text('Client_last_name', null, 
            array('required',
            'class'=>'form-control',
            'placeholder'=> ' Client last name'
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has(' Client_last_name')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first(' Client_last_name') }}
                            </p>
                             @endif
</div>
</div>
</div>

<div class="row">
 <div class="col-md-6 col-sm-6 col-xs-12">
<div class="form-group">
    {!! Form::label('Starting date') !!}
    <div >
        {!! Form::date('Starting_date', null, 
            array('required',
            'class'=>'form-control',
            'id'=>'startdate',
            'placeholder'=> 'Service Type '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
     @if ($errors->has('Starting_date ')) 
                            <p class="help-block" style="color: Red">
                            {{ $errors->first('Starting_date') }}
                            </p>
                             @endif

</div>
</div>

 <div class="col-md-6 col-sm-6 col-xs-12">
<div class="form-group">
    {!! Form::label('Ending Date')!!}
    <div >
        {!! Form::date('Ending_Date', null, 
            array('required',
            'class'=>'form-control',
            'id'=>'enddate',
            'placeholder'=> 'Ending_Date '
            )) !!}
        <div class="help-block with-errors"></div>
    </div>
      @if ($errors->has('Ending_Date '))
                             <p class="help-block" style="color: Red">
                             {{ $errors->first('Ending_Date ') }}
                             </p> 
                             @endif
</div>
</div>
</div>

<div class="col-xs-12">
   <div class="form-group">
    {!! Form::submit('Submit', 
      array('class'=>'btn btn-primary')) !!}
</div>
</div>

{!! Form::close() !!}