
@include('abc')
<meta charset='utf-8' />
<link href='vendor/assets/fullcalendar.min.css' rel='stylesheet' />
<link href='vendor/assets/fullcalendar.print.min.css' rel='stylesheet' media='print' />
<script src='vendor/assets/lib/moment.min.js'></script>
<script src='vendor/assets/lib/jquery.min.js'></script>
<script src='vendor/assets/fullcalendar.min.js'></script>
<script>

  $(document).ready(function() {

    
    var token=$('meta[name="csrf-token"]').attr('content');
  

    $('#calendar').fullCalendar({
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay'
      },
      defaultDate: moment(),
      navLinks: true, // can click day/week names to navigate views
      editable: false,
      eventLimit: true, // allow "more" link when too many events
        allDayDefault: false,
            allDaySlot: false,
            slotEventOverlap: false,
      // weekends:false
      //

      /* events: [ 
      
      ] */

  //events:'/getCalendar.json',
// is code  sample  kider hai ? net pr
  events: function(start, end, timezone, callback) {
      $.ajax({
        url: '/cal',
        datatype: 'json',
              
        success: function(result) {
          
          var events = [];
          $.each(result, function(i, value) {
                 console.log(value);

            events.push({
              title: result[i].event_name +' ' +'by'+ ' ' + result[i].client_id,
              start: result[i].start_confirmed_date,
                end: result[i].end_confirmed_date,
              id: result[i].event_id,
              //all data
            });
            //console.log(value)
          });
         callback(events);
        },
        
      });
    },  

/*hiddenDays:  function(days, callback) {
      $.ajax({
        url: '/cal',
        datatype: 'json',
              
        success: function(result) {
          
          var events = [];
          $.each(result, function(i, value) {
                 console.log(value);

            events.push({
              title: result[i].event_name  +'by'+  result[i].client_id,
              start: result[i].start_confirmed_date,
                end: result[i].end_confirmed_date,
            
              //all data
            });
            //console.log(value)
          });
         callback(events);
        },
        
      });
    },*/



 eventClick: function (event, jsEvent, view) {
       

        var deleteit=confirm("Are you sure to delete event??");
        if(deleteit){

            $.ajax({
              type: "POST",
               url:"{{ route('deleteCalEvent')}}",
               data: {
                 data:event._id,
                _token :token,

              },

            
              
               success: function (data) {
                    $('#calendar').fullCalendar('removeEvents', data);
                    //console.log("event deleted");
                }
            });
        }
      },


      eventMouseover: function( event, jsEvent, view ) { 
        var start = event.start.format("HH:mm");
        
        if(event.end){
            var end = event.end.format("HH:mm");
        }
  else{var end="Not declared";
        }

        ;

        var tooltip = '<div class="tooltipevent" style="width:150px;height:100px;color:white;background:black;position:absolute;z-index:10001;">'+'<center>'+ event.title +'</center>' +'Start at: '+start+'<br>'+ 'End at: '+ end +'</div>';
        $("body").append(tooltip);
        $(this).mouseover(function(e) {
          $(this).css('z-index', 10000);
          //$('.tooltipevent').fadeIn('500');
          //$('.tooltipevent').fadeTo('10', '1');
          $('.tooltipevent').fadeOut('100000', 'swing');
        }).mousemove(function(e) {
          $('.tooltipevent').css('top', e.pageY + 10);
          $('.tooltipevent').css('left', e.pageX + 20);
        });            
      },
           

});

    });
    
  

</script>
<style>

  body {
    
  }

  #calendar {
    
  }

</style>



  
    <div class="container" style="margin: 40px 160px;z-index: 800
    padding: 0;
    font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
    font-size: 14px;">

     <div id='calendar' style="max-width: 900px;
    margin: 0 auto;"> 
    </div>
    
    </div>
   

  
