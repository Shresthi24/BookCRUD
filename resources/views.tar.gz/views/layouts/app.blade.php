<html>
    <Head>
        <title>Mea-Vita - @yield('title')</title>
<link rel="icon" href="{!! asset('images/title-icon.png') !!}"/>
        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="Jasper">

        <!-- Bootstrap Core CSS -->
        <link href="{{asset('css/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" >

        <!-- MetisMenu CSS -->
        <link href="{{asset('css/vendor/metisMenu/metisMenu.min.css')}}" rel="stylesheet">

        <!-- form css -->

        <link href="{{asset('css/dist/css/parentform.css')}}" rel="stylesheet"  type="text/css">

        <!-- fontawesome -->
        <link href="{{asset('css/vendor/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css">

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.slim.min.js"></script>


        <!-- jQuery -->
        <script src="{{asset('css/vendor/jquery/jquery.min.js')}}"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="{{asset('css/vendor/bootstrap/js/bootstrap.min.js')}}"></script>

        <!-- custom css -->
        <link rel="stylesheet" href="{{asset('css/dist/css/indexstyle.css')}}" type="text/css">

        <!-- custom js -->
        <script type="text/javascript" src="{{asset('js/dist/js/index.js')}}"></script>

        <script>
window.Laravel = <?php
echo json_encode([
    'csrfToken' => csrf_token(),
]);
?>
        </script>

        <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"> -->
    </Head>
    <body>
        <nav class="navbar  navbar-static-top" style="background-color: #f8f8f8 ;opacity: 0.8" id="navbarheight" role="navigation">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>


                        <div>
                            <img src="{{asset('images/Meavita.png')}}"  class="logo-style" style=" margin-top: 10px; margin-left:28px; height:50px ;">


                        </div>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="height: 72px !important">


                        <ul class="nav navbar-nav navbar-right" style="margin-top: 10px; margin-left:28px;">
                            @if (Auth::guest())
                       <!--     <li><p class="navbar-text">Already have an account?</p></li> -->
                            <li class="dropdown">
                                   
                                       
                            <li><a href="{{ url('/login') }}">Login</a></li>
                            <li><a href="{{ url('/register') }}">Register</a></li>
                       
                            @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
    
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="{{ url('/logout') }}"
                                           onclick="event.preventDefault();
                                                   document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>

                                    
                                </ul>

                                @endif

                            </li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container-fluid -->
            </div>
        </nav>


        @yield('welcome')  
        @yield('content')

    </body>
</html>