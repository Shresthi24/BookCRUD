<?php
?>
<!DOCTYPE html>
<html>
<head>
	<title>Hi</title>
</head>
<body>
<p>Jasper pagal hai</p>
</body>
</html>