@include('abc')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$(#hide).click(function(){
   var row = $(this).closest('tr');

   row.remove();
   
});
  
    

</script>
	<div class="container-fluid"  style="padding-left: 270px">
<table class="table table-striped table-bordered table-success table-sm	"  style="border:1px solid black; border-collapse: collapse;width:100%">
		<thead class="thead-inverse" style="background-color: #dff0d8">
	  <tr>
        

        <th style="padding: 3px;border-bottom: 1px solid black;width:5%">ClinetId</th>
        <th style="padding: 3px;border-bottom: 1px solid black;">FirstName</th>
        
		<th style="padding: 3px;border-bottom: 1px solid black;">lastname</th>
        <th style="padding: 3px;border-bottom: 1px solid black;width:10%">start_date</th>
		<th style="padding: 3px;border-bottom: 1px solid black;width:10%">end_date</th>
		<th style="padding: 3px;border-bottom: 1px solid black;width:5%">Max_Guest</th>
		<th style="padding: 3px;border-bottom: 1px solid black;width:5%">Min_Guest</th>
		<th style="padding: 3px;border-bottom: 1px solid black;width:8%">Budget</th>
		<th style="padding: 3px;border-bottom: 1px solid black;width:15%">Comments</th>
		<th style="padding: 3px;border-bottom: 1px solid black;width:15%">Actions</th>
</tr>
</thead>
		
	    @foreach($client as $Clients)
	  <tr id="tobehide" data-href= "{{ ('bookingdatafetchbyclick')}}"> 
	      <th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->Client_id }}</th>
	     <th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->Client_first_name}}</th>
	    
	     <th style="padding: 3px;border-bottom: 1px solid black;">{{  $Clients->Client_last_name}}</th>
		 <th style="padding: 3px;border-bottom: 1px solid black;">{{ $Clients->Tentative_start_date}}</th>
         <th style="padding: 3px;border-bottom: 1px solid black;">{{ $Clients->Tentative_end_date}}</th>		 
		 <th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->Max_footfall}}</th>
		<th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->Min_Footfall}}</th>
		<th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->Budget}}</th>
		<th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->comments_events}}</th>
		<th style="padding: 3px;border-bottom: 1px solid black;">
		
		<div class="row" >
			
			<div class="col-md-6">
			<a href="{{('requesteventaccept/'. $Clients->Event_id)}}" class="teal-text" ><i class="fa fa-check" style="color: green" id="hide"></i></a>
			</div>

	
                <div class="col-md-6">
			<a href="{{('requesteventreject/'. $Clients->Event_id)}}" class="red-text" ><i class="fa fa-times" id="hide" style="color: red" id="hide"></i></a>
			</div>
                
                </div>
            </th>
		
	     
		 
		  
	  </tr>
	  
@endforeach	  




	  </table>



 




	</div>


