@include('abc')
@section('css')
<link rel="stylesheet" href="{{ asset('tour.css') }}">
@endsection



<div class="container-fluid" style="z-index: 800;">


        <div class="row" >
         <div class="col-md-4 col-sm-3">
</div>
            
                <div class="col-md-4 col-sm-6 col-xs-12">
                   <a href="#" title="Balance Payments">
    <div class="info-box" style="display: block;min-height: 90px;background: #fff;width: 100%;box-shadow: 0 1px 1px rgba(0,0,0,.1);
border-radius: 2px;margin-bottom: 15px;">

<span class="info-box-icon bg-green " style="border-top-left-radius: 2px;border-top-right-radius: 0;background-color: green !important;border-bottom-right-radius: 0;border-bottom-left-radius: 2px;display: block;float: left;height: 90px;width: 90px;
text-align: center;font-size: 45px;line-height: 90px;background: rgba(0,0,0,.2);text-align: centre;top-padding:10px">

<i class="fa fa-calculator" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;color: #fff !important;text-rendering: auto;align:center;top-margin:10px"></i></span>


    <div class="info-box-content" style="top-margin:30px">
      <span class="info-box-text" style="display: block;font-size: 24px;white-space: nowrap;overflow: hidden;text-overflow:ellipsis;text-align:center;top-margin:25px">Balance Payments</span>
     
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
</a>
                </div>
            </div>


        <div class="row" >
            <div class="col-md-4 col-sm-3">
</div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                     <a href="#" title="Completed Payments">
    <div class="info-box" style="display: block;min-height: 90px;background: #fff;width: 100%;box-shadow: 0 1px 1px rgba(0,0,0,.1);
border-radius: 2px;margin-bottom: 15px;">


<span class="info-box-icon bg-green " style="border-top-left-radius: 2px;border-top-right-radius: 0;background-color: #00a65a !important;border-bottom-right-radius: 0;border-bottom-left-radius: 2px;display: block;float: left;height: 90px;width: 90px;
text-align: center;font-size: 45px;line-height: 90px;background: rgba(0,0,0,.2);text-align: centre;top-padding:10px">

<i class="fa fa-check" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;color: #fff !important;text-rendering: auto;align:center;top-margin:10px"></i></span>

    <div class="info-box-content">
      <span class="info-box-text" style="display: block;font-size: 24px;white-space: nowrap;overflow: hidden;text-overflow:ellipsis; text-align:center">Completed Payments</span>
     
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
</a>
                </div>
            </div>


        <div class="row" >
            <div class="col-md-4 col-sm-3">
</div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                   <a href="#" title="Total Earnings">
    <div class="info-box" style="display: block;min-height: 90px;background: #fff;width: 100%;box-shadow: 0 1px 1px rgba(0,0,0,.1);
border-radius: 2px;margin-bottom: 15px;">


<span class="info-box-icon bg-green " style="border-top-left-radius: 2px;border-top-right-radius: 0;background-color: #00a65a !important;border-bottom-right-radius: 0;border-bottom-left-radius: 2px;display: block;float: left;height: 90px;width: 90px;
text-align: center;font-size: 45px;line-height: 90px;background: rgba(0,0,0,.2);text-align: centre;top-padding:20px">

<i class="fa fa-credit-card-alt" style="display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;color: #fff !important;text-rendering: auto;align:center;top-margin:10px"></i></span>

    <div class="info-box-content">
      <span class="info-box-text" style="display: block;font-size: 24px;white-space: nowrap;overflow: hidden;text-overflow:ellipsis;text-align:center">Total Earnings</span>
      <span class="info-box-number"><h2><center>{{ $client}}</center></h2></span>
     
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
</a>
    
                </div>
            </div>







