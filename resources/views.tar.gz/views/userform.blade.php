


@extends('layouts.app')
@section('content')

<script src="js/jquery.min.js" type="text/javascript"></script>
<script>
 $(document).ready(function() {
  $('#li a check').on("click",function() {
   
   $('#main').show(show);
  });
 });
</script>

<section class="upper-section" style="padding-top:0 !important">
  <div class="container-fluid">


  <div class="main-sidebar" style="background-color:#222d32;width:250px;top: 0px;left: 0px;position: fixed;opacity: 0.5">

  <section class="sidebar" style="position:fixed;">            




<ul class="sidebar-menu" style="white-space: nowrap;overflow: hidden;list-style: none;
left-margin: 0;padding-left: 0px;padding-top: 20px;">
      

    <!-- Optionally, you can add icons to the links -->
    <li  title="User Details">
<a id= "check" href="{{ ('#')}}"  style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;border-left: 3px solid transparent;color: white;margin-left: 0">
               <i class="fa fa-user"></i>
            <span>User Details</span>
        </a>
    </li>

    <li class="" title="Company Details">
        <a href="{{ ('#')}}" style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;color: white">
        <i class="fa fa-building-o"></i>
            <span>Company Details</span>
        </a>
    </li>

    <li class="" title="Payments Details">
        <a href="{{ ('#')}}" style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;color: white">
        <i class="fa fa-credit-card "></i>
            <span>Payments Details</span>
        </a>
    </li>

</ul>
<!-- /.sidebar-menu -->

            </section>

 <hr style="width:0.5px; height:650px">

 </div> 

 


</div>
</section>



   @endsection

  @yield('menu')


@include('resusable.footer')






