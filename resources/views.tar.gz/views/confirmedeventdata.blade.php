@include('abc')
<script src='vendor/assets/lib/jquery.min.js'></script>
<script>
 jQuery(document).ready(function($) {
    $(".clickable-row").click(function() {
        window.location = $(this).data("href");
    });
});

</script>
	<div class="container-fluid" style="padding-left: 270px">
<table class="table table-striped table-bordered table-success table-sm	" style="border:1px solid black; border-collapse: collapse;width:100%">
		<thead class="thead-inverse" style="background-color: #dff0d8">
	  <tr>
        

        <th style="padding: 3px;border-bottom: 1px solid black;width:15%">ClinetId</th>
        <th style="padding: 3px;border-bottom: 1px solid black;">FirstName</th>
        
		<th style="padding: 3px;border-bottom: 1px solid black;">lastname</th>
        <th style="padding: 3px;border-bottom: 1px solid black;width:15%">Confirm_date</th>
		
		
</tr>
</thead>
		
	    @foreach($client as $Clients)
	  <tr class='clickable-row' data-href= "{{ ('bookingdatafetchbyclick')}}"> 
	      <th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->Client_id }}</th>
	     <th style="padding: 3px;border-bottom: 1px solid black;">{{$Clients->Client_first_name}}</th>
	    
	     <th style="padding: 3px;border-bottom: 1px solid black;">{{  $Clients->Client_last_name}}</th>
		
         <th style="padding: 3px;border-bottom: 1px solid black;">{{ $Clients->Confirmed_start_date}}</th>		 
		
		
		
	     
		 
		  
	  </tr>
	  
@endforeach	  




	  </table>



 




	</div>


