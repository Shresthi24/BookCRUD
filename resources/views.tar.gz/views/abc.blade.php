


@extends('layouts.app')
@section('content')

<script src="js/jquery.min.js" type="text/javascript"></script>
<script>
 $(document).ready(function() {
  $('#li a check').on("click",function() {
   
   $('#main').show(show);
  });
 });
</script>

<section class="upper-section" style="padding-top:0 !important">
  <div class="container-fluid">


  <div class="main-sidebar" style="background-color:#222d32;width:250px;top: 0px;left: 0px;position: fixed;opacity: 0.5">

  <section class="sidebar" style="position:fixed;">            




<ul class="sidebar-menu" style="white-space: nowrap;overflow: hidden;list-style: none;
left-margin: 0;padding-left: 0px;padding-top: 20px;">
      

    <!-- Optionally, you can add icons to the links -->
    <li  title="dashboard">
<a id= "check" href="{{ ('show')}}"  style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;border-left: 3px solid transparent;color: white;margin-left: 0">
            <i class="fa fa-tachometer"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <li class="" title="Booking">
        <a href="{{ ('book')}}" style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;color: white">
            <i class="fa fa-calendar-check-o"></i>
            <span>Booking</span>
        </a>
    </li>

    <li class="" title="Revenues">
        <a href="{{ ('rev')}}" style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;color: white">
            <i class="fa fa-calendar-check-o"></i>
            <span>Revenues</span>
        </a>
    </li>

    <li class="" title="Utilization">
        <a href="{{('utilize')}}" style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;color: white">
            <i class="fa fa-calendar"></i>
            <span>Utilization</span>
        </a>
    </li>

    <li class="" title="Customers">
        <a href="{{ ('cus')}}"  style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;color: white">
            <i class="fa fa-users"></i>
            <span>Customers</span>
        </a>
    </li>

    <li class="" title="Payments">
        <a href="{{ ('pay')}}"  style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;color: white">
            <i class="fa fa-credit-card "></i>
            <span>Payments</span>
        </a>
    </li>

    <li class="" title="Support">
        <a  href="{{ url('http://faq.isirs.org/public/productBasedFAQ/2') }}" target="_blank" style="padding: 12px 5px 12px 15px;display: block;position: relative;border-left: 3px solid transparent;color: white">
            <i class="fa fa-commenting-o "></i>
            <span>Support</span>
        </a>
    </li>

  



</ul>
<!-- /.sidebar-menu -->

            </section>

 <hr style="width:0.5px; height:650px">

 </div> 

 


</div>
</section>



   @endsection

  @yield('menu')


@include('resusable.footer')






